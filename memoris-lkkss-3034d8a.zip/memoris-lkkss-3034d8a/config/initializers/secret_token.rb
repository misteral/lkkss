# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Lkksswin::Application.config.secret_token = 'dba70c7c46c639ec5adf67da742f543440690e709d11df2dd5f099ce09c57241655fe56dec1dcb502868931dada9c700738fc23c477352b8b28314b72ba8073e'
