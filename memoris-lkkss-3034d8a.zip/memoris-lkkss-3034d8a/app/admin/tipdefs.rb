ActiveAdmin.register Tipdef do
  
end
