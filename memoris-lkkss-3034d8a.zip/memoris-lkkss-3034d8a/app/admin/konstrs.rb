ActiveAdmin.register Konstr do
  
end
