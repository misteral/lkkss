ActiveAdmin.register Ntrub do
  
end
