ActiveAdmin.register Zavod do
  
end
