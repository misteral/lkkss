class GuideController < ApplicationController
  def index
  end

end
