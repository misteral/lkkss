class GostsController < InheritedResources::Base
end
