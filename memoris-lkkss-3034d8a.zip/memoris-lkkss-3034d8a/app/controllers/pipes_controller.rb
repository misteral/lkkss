class PipesController < InheritedResources::Base
end
