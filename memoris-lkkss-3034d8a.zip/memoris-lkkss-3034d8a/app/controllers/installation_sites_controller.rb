class InstallationSitesController < InheritedResources::Base
end
