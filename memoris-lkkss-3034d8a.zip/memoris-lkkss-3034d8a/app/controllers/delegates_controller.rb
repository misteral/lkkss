class DelegatesController < InheritedResources::Base
end
