class ResultsController < InheritedResources::Base
end
