class TypePipeInstallationSitesController < InheritedResources::Base
end
