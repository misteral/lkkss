class JournalController < ApplicationController
  def index
  end

  def link
  end

end
