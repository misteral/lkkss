class AktsController < InheritedResources::Base
end
