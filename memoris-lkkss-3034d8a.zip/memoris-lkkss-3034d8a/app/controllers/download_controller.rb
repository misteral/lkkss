class DownloadController < ApplicationController
  def rem
  end

end
