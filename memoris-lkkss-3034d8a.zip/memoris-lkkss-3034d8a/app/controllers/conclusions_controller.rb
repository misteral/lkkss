class ConclusionsController < InheritedResources::Base
end
