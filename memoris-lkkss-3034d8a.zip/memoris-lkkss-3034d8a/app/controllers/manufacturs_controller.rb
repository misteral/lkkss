class ManufactursController < InheritedResources::Base
end
