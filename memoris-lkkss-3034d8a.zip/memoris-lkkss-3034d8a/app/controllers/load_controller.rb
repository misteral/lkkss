class LoadController < ApplicationController
  def index
  end

  def rem
  end

end
