class DataPipesController < InheritedResources::Base
end
