class TipdefsController < InheritedResources::Base
end
