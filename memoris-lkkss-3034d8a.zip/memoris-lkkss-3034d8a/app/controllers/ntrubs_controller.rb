class NtrubsController < InheritedResources::Base
end
