class CertificatesController < InheritedResources::Base
end
