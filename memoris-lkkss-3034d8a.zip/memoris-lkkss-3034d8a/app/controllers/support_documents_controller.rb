class SupportDocumentsController < InheritedResources::Base
end
