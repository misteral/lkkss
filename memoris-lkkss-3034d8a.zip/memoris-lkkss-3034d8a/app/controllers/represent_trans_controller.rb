class RepresentTransController < InheritedResources::Base
end
