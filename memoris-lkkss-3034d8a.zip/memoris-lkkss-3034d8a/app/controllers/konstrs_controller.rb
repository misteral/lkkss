class KonstrsController < InheritedResources::Base
end
