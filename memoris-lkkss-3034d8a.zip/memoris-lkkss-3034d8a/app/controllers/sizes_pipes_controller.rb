class SizesPipesController < InheritedResources::Base
end
