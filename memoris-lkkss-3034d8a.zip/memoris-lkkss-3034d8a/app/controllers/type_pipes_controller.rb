class TypePipesController < InheritedResources::Base
end
