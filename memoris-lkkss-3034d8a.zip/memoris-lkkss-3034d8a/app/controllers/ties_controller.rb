class TiesController < InheritedResources::Base
end
