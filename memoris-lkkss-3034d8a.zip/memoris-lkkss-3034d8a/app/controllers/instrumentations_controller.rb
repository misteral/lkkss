class InstrumentationsController < InheritedResources::Base
end
