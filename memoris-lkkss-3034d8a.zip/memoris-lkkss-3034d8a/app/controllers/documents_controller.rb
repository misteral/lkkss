class DocumentsController < InheritedResources::Base
end
