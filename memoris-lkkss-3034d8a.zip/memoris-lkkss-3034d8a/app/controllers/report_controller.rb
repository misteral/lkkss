class ReportController < ApplicationController
  def index
  end

end
