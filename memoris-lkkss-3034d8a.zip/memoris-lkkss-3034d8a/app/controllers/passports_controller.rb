class PassportsController < InheritedResources::Base
end
