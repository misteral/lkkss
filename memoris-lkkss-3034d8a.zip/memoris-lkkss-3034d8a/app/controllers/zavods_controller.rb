class ZavodsController < InheritedResources::Base
end
