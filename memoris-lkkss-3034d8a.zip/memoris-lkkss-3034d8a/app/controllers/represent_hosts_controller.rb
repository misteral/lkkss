class RepresentHostsController < InheritedResources::Base
end
