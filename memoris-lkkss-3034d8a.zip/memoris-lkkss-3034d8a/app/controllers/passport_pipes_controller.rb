class PassportPipesController < InheritedResources::Base
end
