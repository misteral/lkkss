class TerrasController < InheritedResources::Base
end
