class Magazine < ActiveRecord::Base
end
