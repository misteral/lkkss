class TypePipe < ActiveRecord::Base
   has_many :certificates
end
