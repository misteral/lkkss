class Instrumentation < ActiveRecord::Base
  has_many :certificates
end
