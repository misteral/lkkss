class PassportPipe < ActiveRecord::Base
  belongs_to :passport
  belongs_to :pipe
end
