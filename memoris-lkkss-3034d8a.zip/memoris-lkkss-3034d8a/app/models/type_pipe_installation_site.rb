class TypePipeInstallationSite < ActiveRecord::Base
#  belongs_to :pipe
#  belongs_to :installation_site
end
