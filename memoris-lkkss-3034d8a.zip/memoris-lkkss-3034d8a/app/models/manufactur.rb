class Manufactur < ActiveRecord::Base
  has_many :certificates
end
