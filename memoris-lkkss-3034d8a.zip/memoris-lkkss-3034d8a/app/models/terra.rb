class Terra < ActiveRecord::Base
end
