class Zavod < ActiveRecord::Base
  has_many :akts
end
