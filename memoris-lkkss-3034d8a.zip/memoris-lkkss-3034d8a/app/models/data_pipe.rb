class DataPipe < ActiveRecord::Base
  has_many :pipes
end
