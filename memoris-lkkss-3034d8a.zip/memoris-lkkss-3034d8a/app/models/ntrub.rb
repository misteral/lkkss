class Ntrub < ActiveRecord::Base
  has_many :akts
end
