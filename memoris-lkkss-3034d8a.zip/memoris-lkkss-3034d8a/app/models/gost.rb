class Gost < ActiveRecord::Base
  has_many :certificates
end
