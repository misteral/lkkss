class Konstr < ActiveRecord::Base
  has_many :akts
end
