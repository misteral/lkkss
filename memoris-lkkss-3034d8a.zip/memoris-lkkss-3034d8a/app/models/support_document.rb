class SupportDocument < ActiveRecord::Base
  has_many :certificates
end
