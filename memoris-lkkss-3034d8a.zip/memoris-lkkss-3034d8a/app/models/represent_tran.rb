class RepresentTran < ActiveRecord::Base
  has_many :certificates
end
