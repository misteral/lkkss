class Tipdef < ActiveRecord::Base
  has_many :akts
end
