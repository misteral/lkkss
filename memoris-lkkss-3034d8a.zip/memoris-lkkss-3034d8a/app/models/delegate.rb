class Delegate < ActiveRecord::Base
  has_many :certificates
end
