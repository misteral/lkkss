class RepresentHost < ActiveRecord::Base
  has_many :certificates
end
