class Ty < ActiveRecord::Base
  has_many :certificates
end
