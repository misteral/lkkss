class InstallationSite < ActiveRecord::Base
  has_many :certificates
end
