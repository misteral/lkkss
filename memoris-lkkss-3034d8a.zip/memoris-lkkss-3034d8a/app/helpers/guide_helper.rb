module GuideHelper
end
