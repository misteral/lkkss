module TypePipesHelper
end
