module JournalHelper
end
