module GostsHelper
end
