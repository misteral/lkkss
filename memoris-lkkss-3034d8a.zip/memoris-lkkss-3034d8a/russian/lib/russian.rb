require "russian/version"

module Russian
  # Your code goes here...
end
