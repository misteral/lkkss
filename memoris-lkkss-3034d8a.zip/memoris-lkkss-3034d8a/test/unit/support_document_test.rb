require 'test_helper'

class SupportDocumentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
