require 'test_helper'

class RepresentHostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
