require 'test_helper'

class DataPipeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
