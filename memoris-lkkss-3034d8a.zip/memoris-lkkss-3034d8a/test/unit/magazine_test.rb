require 'test_helper'

class MagazineTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
