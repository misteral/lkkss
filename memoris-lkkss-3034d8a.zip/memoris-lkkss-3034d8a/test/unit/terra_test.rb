require 'test_helper'

class TerraTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
