require 'test_helper'

class ManufactursHelperTest < ActionView::TestCase
end
