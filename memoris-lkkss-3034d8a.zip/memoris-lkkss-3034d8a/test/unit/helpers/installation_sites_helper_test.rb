require 'test_helper'

class InstallationSitesHelperTest < ActionView::TestCase
end
