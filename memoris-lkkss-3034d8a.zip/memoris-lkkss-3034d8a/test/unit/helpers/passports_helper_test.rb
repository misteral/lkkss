require 'test_helper'

class PassportsHelperTest < ActionView::TestCase
end
