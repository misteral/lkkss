require 'test_helper'

class PipesHelperTest < ActionView::TestCase
end
