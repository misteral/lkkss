require 'test_helper'

class MagazinesHelperTest < ActionView::TestCase
end
