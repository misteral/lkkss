require 'test_helper'

class GostsHelperTest < ActionView::TestCase
end
