require 'test_helper'

class RepresentTransHelperTest < ActionView::TestCase
end
