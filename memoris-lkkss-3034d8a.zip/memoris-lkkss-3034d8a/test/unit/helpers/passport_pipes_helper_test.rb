require 'test_helper'

class PassportPipesHelperTest < ActionView::TestCase
end
