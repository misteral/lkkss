require 'test_helper'

class DownloadHelperTest < ActionView::TestCase
end
