require 'test_helper'

class DataPipesHelperTest < ActionView::TestCase
end
