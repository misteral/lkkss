require 'test_helper'

class AktsHelperTest < ActionView::TestCase
end
