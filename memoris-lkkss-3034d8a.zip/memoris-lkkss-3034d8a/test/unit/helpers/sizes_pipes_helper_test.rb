require 'test_helper'

class SizesPipesHelperTest < ActionView::TestCase
end
