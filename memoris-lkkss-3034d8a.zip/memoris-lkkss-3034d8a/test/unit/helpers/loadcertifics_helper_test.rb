require 'test_helper'

class LoadcertificsHelperTest < ActionView::TestCase
end
