require 'test_helper'

class TiesHelperTest < ActionView::TestCase
end
