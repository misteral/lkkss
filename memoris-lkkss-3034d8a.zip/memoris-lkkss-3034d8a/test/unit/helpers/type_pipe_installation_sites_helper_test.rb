require 'test_helper'

class TypePipeInstallationSitesHelperTest < ActionView::TestCase
end
