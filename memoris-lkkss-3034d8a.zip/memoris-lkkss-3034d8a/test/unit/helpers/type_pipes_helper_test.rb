require 'test_helper'

class TypePipesHelperTest < ActionView::TestCase
end
