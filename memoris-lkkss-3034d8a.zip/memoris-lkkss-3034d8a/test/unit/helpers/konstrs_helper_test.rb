require 'test_helper'

class KonstrsHelperTest < ActionView::TestCase
end
