require 'test_helper'

class TerrasHelperTest < ActionView::TestCase
end
