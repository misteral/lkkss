require 'test_helper'

class ReportHelperTest < ActionView::TestCase
end
