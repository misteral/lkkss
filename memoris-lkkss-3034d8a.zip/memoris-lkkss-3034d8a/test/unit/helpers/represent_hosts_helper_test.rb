require 'test_helper'

class RepresentHostsHelperTest < ActionView::TestCase
end
