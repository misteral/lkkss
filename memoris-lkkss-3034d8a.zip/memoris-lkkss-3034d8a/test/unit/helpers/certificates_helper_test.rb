require 'test_helper'

class CertificatesHelperTest < ActionView::TestCase
end
