require 'test_helper'

class ZavodsHelperTest < ActionView::TestCase
end
