require 'test_helper'

class InstrumentationsHelperTest < ActionView::TestCase
end
