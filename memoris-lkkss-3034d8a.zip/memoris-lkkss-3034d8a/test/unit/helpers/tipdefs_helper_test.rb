require 'test_helper'

class TipdefsHelperTest < ActionView::TestCase
end
