require 'test_helper'

class JournalHelperTest < ActionView::TestCase
end
