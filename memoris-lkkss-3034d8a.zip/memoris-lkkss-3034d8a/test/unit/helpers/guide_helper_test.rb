require 'test_helper'

class GuideHelperTest < ActionView::TestCase
end
