require 'test_helper'

class SupportDocumentsHelperTest < ActionView::TestCase
end
