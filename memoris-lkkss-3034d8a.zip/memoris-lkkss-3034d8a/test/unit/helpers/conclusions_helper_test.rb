require 'test_helper'

class ConclusionsHelperTest < ActionView::TestCase
end
