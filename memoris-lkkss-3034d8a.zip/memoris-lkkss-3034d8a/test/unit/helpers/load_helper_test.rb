require 'test_helper'

class LoadHelperTest < ActionView::TestCase
end
