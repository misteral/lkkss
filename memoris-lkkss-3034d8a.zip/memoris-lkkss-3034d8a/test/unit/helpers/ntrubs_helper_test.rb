require 'test_helper'

class NtrubsHelperTest < ActionView::TestCase
end
