require 'test_helper'

class DelegatesHelperTest < ActionView::TestCase
end
