require 'test_helper'

class RepresentTranTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
