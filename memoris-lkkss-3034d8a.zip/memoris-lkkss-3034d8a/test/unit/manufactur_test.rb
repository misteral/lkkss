require 'test_helper'

class ManufacturTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
