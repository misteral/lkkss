require 'test_helper'

class InstrumentationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
