require 'test_helper'

class PipeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
