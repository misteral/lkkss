require 'test_helper'

class SizesPipeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
