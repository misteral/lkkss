require 'test_helper'

class PassportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
