require 'test_helper'

class TypePipeInstallationSiteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
