require 'test_helper'

class NtrubTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
